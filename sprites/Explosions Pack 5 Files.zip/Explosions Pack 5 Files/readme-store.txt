Read me File

Thanks for purchasing this Art Asset Pack hope you find it useful.
The downloadable file contains everything you need to start working right away on your game project.

Thanks Again

Created by Ansimuz www.ansimuz.com
Visit my site for free resources at www.ansimuz.com

follow me at twitter @ansimuz